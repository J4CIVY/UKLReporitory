package Presentacion;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Inicio {
    private JPanel panel1;
    private JButton btnUsuario;
    private JButton btnColaborador;
    private JButton button1;

    public Inicio() {
        btnUsuario.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                JFrame frame = new JFrame("Usuario");
                frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
                InicioUsuario inicioUsuario = new InicioUsuario();
                frame.setContentPane(inicioUsuario.getPanel1());
                frame.pack();
                frame.setVisible(true);
            }
        });
    }

    public JPanel getPanel1 (){
        return this.panel1;
    }
}
