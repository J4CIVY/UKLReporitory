package Presentacion;

import javax.swing.*;

public class InicioUsuario {
    private JPanel panel1;
    private JTextField textField1;
    private JTextField textField2;
    private JButton button1;
    private JButton button2;

    public JPanel getPanel1() {
        return this.panel1;
    }
}