import Presentacion.Inicio;
import javax.swing.*;
import java.awt.*;

public class Main {

    public static void main(String[] args) {

        JFrame frame = new JFrame("Inicio");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        Inicio inicio = new Inicio();
        frame.setContentPane(inicio.getPanel1());
        frame.pack();
        frame.setSize(600, 980);
        frame.setVisible(true);
    }
}