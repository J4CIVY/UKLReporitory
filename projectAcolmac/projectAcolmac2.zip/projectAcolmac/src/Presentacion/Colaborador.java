package Presentacion;

public class Colaborador {
}
