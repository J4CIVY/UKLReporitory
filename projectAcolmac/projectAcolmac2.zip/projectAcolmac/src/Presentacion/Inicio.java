package Presentacion;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Inicio extends JFrame{
    private JPanel panel1;
    private JButton btnLoginUser;
    private JButton btnRegisterUser;
    private JButton btnLogSystem;
    private JPanel containerPrincipal;
    private JButton btnUsuario;

    public Inicio() {
        btnLoginUser.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

                InicioUsuario inicioUsuario = new InicioUsuario();

                containerPrincipal.removeAll();
                containerPrincipal.add(inicioUsuario.getPnlUserRegister());
                containerPrincipal.revalidate();
                containerPrincipal.repaint();
            }
        });
    }

    public JPanel getPanel1 (){

        return this.panel1;
    }
}
