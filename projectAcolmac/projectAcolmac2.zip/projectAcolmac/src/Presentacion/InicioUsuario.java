package Presentacion;

import javax.swing.*;

public class InicioUsuario extends JFrame{
    private JPanel pnlUserRegister;

    public JPanel getPnlUserRegister() {

        return this.pnlUserRegister;
    }
}