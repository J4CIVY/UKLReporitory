package Presentacion;

import Logica.BuscadorDTO;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class buscador {
    private JPanel panel1;
    private JTextField txtBuscador;
    private JButton btnBuscar;
public buscador() {
    btnBuscar.addActionListener(new ActionListener() {
        @Override
        public void actionPerformed(ActionEvent e) {
            System.out.println(txtBuscador.getText());
            BuscadorDTO buscadorDTO = new BuscadorDTO(txtBuscador.getText());
            buscadorDTO.procesarBusqueda();
        }
    });
}

public JPanel getPanel1(){
    return this.panel1;
}
}
